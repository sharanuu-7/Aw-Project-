# Databricks notebook source
# MAGIC %md
# MAGIC ##Sliver layer script

# COMMAND ----------

# MAGIC %md
# MAGIC ####Data source

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *


# COMMAND ----------


spark.conf.set("fs.azure.account.auth.type.projectawstorage.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.projectawstorage.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.projectawstorage.dfs.core.windows.net", "a77d48cd-f049-4d14-b27c-c41e931c0b4d")
spark.conf.set("fs.azure.account.oauth2.client.secret.projectawstorage.dfs.core.windows.net", "JyC8Q~2EGAuR639ynuXOgmsJ8Oz5nz18QlBiRdiE")
spark.conf.set("fs.azure.account.oauth2.client.endpoint.projectawstorage.dfs.core.windows.net", "https://login.microsoftonline.com/bed6ecb3-2491-4fa3-a611-1f617467511d/oauth2/token")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data load

# COMMAND ----------

# MAGIC %md
# MAGIC ####Read all the files
# MAGIC

# COMMAND ----------

df_cal = spark.read.format('csv').option('header',True).option('inferSchema',True).load('abfss://bronze@projectawstorage.dfs.core.windows.net/AdventureWorks_Calendar')

# COMMAND ----------

df_pro = spark.read.format('csv').option('header',True).option('inferSchema',True).load('abfss://bronze@projectawstorage.dfs.core.windows.net/AdventureWorks_Products')

# COMMAND ----------

df_cat = spark.read.format('csv').option('header',True).option('inferSchema',True).load('abfss://bronze@projectawstorage.dfs.core.windows.net/AdventureWorks_Product_Categories')

# COMMAND ----------

df_sub = spark.read.format('csv').option('header',True).option('inferSchema',True).load('abfss://bronze@projectawstorage.dfs.core.windows.net/AdventureWorks_Product_Subcategories')

# COMMAND ----------

df_ret = spark.read.format('csv').option('header',True).option('inferSchema',True).load('abfss://bronze@projectawstorage.dfs.core.windows.net/AdventureWorks_Returns')

# COMMAND ----------

df_sal1 = spark.read.format('csv').option('header',True).option('inferSchema',True).load('abfss://bronze@projectawstorage.dfs.core.windows.net/AdventureWorks_Sales_2015')

# COMMAND ----------

df_sal2 = spark.read.format('csv').option('header',True).option('inferSchema',True).load('abfss://bronze@projectawstorage.dfs.core.windows.net/AdventureWorks_Sales_2016')

# COMMAND ----------

df_sal3 = spark.read.format('csv').option('header',True).option('inferSchema',True).load('abfss://bronze@projectawstorage.dfs.core.windows.net/AdventureWorks_Sales_2017')

# COMMAND ----------

df_ter = spark.read.format('csv').option('header',True).option('inferSchema',True).load('abfss://bronze@projectawstorage.dfs.core.windows.net/AdventureWorks_Territories')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Transformations

# COMMAND ----------

df_cal.display()

# COMMAND ----------


df_cal=df_cal.withColumn('month',month(col('Date')))\
    .withColumn('year',year(col('Date')))

# COMMAND ----------

df_cal.display()

# COMMAND ----------

df_cal.write.format('parquet').mode('append').option('path','abfss://silver@projectawstorage.dfs.core.windows.net/AdventureWorks_Calendar').save()

# COMMAND ----------

# This file is missing while coping
# df_cus = df_cus.withColumn('FirstName',concat_ws(' ').col('prefix','FirstName','LastName')) 
# Output = Mr Sharan Kanavi

# COMMAND ----------

df_pro.display()

# COMMAND ----------

df_pro=df_pro.withColumn('ProductSKU',split(col('ProductSKU'),'-')[0])\
             .withColumn('ProductName',split(col('ProductName'),' ')[0])

# COMMAND ----------

df_pro.display()

# COMMAND ----------

df_pro.write.format('parquet').mode('append').option('path','abfss://silver@projectawstorage.dfs.core.windows.net/AdventureWorks_Products').save()

# COMMAND ----------

df_cat.display()

# COMMAND ----------

df_cat.write.format('parquet').mode('append').option('path','abfss://silver@projectawstorage.dfs.core.windows.net/AdventureWorks_Product_Categories').save()

# COMMAND ----------

df_sub.display()

# COMMAND ----------

df_sub.write.format('parquet').mode('append').option('path','abfss://silver@projectawstorage.dfs.core.windows.net/AdventureWorks_Product_Subcategories').save()

# COMMAND ----------

df_ret.display()

# COMMAND ----------

df_ret.write.format('parquet').mode('append').option('path','abfss://silver@projectawstorage.dfs.core.windows.net/AdventureWorks_Returns').save()

# COMMAND ----------

df_sal1.display()


# COMMAND ----------

df_sal1 = df_sal1.withColumn("StockDate",to_timestamp(col("StockDate")))

# COMMAND ----------

from pyspark.sql.functions import regexp_replace
df_sal1 = df_sal1.withColumn('OrderNumber', regexp_replace(col('OrderNumber'), 'S', 'T'))


# COMMAND ----------

df_sal1 = df_sal1.withColumn('MultiplayCol', col('OrderLineItem') * col('OrderQuantity'))

# COMMAND ----------

df_sal1.write.format('parquet').mode('append').option('path','abfss://silver@projectawstorage.dfs.core.windows.net/AdventureWorks_Sales').save()

# COMMAND ----------

df_sal1.display()

# COMMAND ----------

df_sal3.display()

# COMMAND ----------

df_sal3= df_sal3.withColumn('multiplycol',col('OrderQuantity')*col('OrderLineItem'))

# COMMAND ----------

df_sal3.write.format('parquet').mode('append').option('path','abfss://silver@projectawstorage.dfs.core.windows.net/AdventureWorks_Sales').save()
df_sal3.display()

# COMMAND ----------

df_sal3= df_sal3.groupBy('OrderDate').agg(count('OrderNumber').alias('TotalOrders'))

# COMMAND ----------

df_sal3.write.format('parquet').mode('append').option('path','abfss://silver@projectawstorage.dfs.core.windows.net/AdventureWorks_Sales').save()
df_sal3.display()

# COMMAND ----------

